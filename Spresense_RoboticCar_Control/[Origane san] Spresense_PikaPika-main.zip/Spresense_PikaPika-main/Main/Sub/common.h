
    #define FFT_SUBCORE_ID 1
    #define DISPLAY_SUBCORE_ID 2

    #define MSGID_FFT_DAT 0
    #define MSGID_FFT_DURATION 1
    #define MSGID_FFT_RESULT 2
    #define MSGID_NO_PEAK 3

    const double FFT_MSG_SCALE = 10000.0;
    const double FFT_MIDSHIFT = 100000000.0;

    #ifdef EQUATION_PARABOLA
    const double Omega_0 = 4.97;     // 固有角速度 [rad\s](拡散)
    const double kappa = 0.4;  // 結合強度（拡散型）
    #else
    const double Omega_0 = 20;     // 固有角速度 [rad\s]（振動）
    const double kappa = 0.5;  // 結合強度（振動型）
    const double my_gamma = 0.20; //　粘性係数
    double C; // 位相更新の定数
    #endif

    const float PEAK_POWER_THRESHOLD = 3.0;   // 観測している位相のピークパワーがこれを下回ったら検出扱いにしない
    const double SELF_EXITATION_INTENSY = 2.0;  // 自励入力の大きさ
    const double GAMMA_CONST_1 = 0.10;    // 動的粘性の定数項
    const double GAMMA_CONST_2 = 0.10;    // 動的粘性のエッジ数に比例する項

    struct EstPacket {
        float estimation;
        uint32_t count;
        bool is_fft_enable;
    };

    // float配列のargmaxを返す
    // @param : float配列のポインタ
    // @param : intデータ長
    // @return : 最大値をとるint添え字
    int argMax(float* dat, int len){
        int argmax = 0;
        float nowmax = 0.0;
        for (int i=0; i<len; i++){
            if(nowmax<dat[i]){
                nowmax = dat[i];
                argmax = i;
            }
        }
        return argmax;
    }

    // ピーク周波数から台数を計算
    // 
    double peakFreqToNum();